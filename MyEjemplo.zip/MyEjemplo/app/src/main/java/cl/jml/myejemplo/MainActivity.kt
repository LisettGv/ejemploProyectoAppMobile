// app/src/main/java/cl/duoc/ntmp/MainActivity.kt
package cl.duoc.ntmp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import cl.duoc.ntmp.ui.CounterScreen
import cl.duoc.ntmp.viewmodel.CounterViewModel
import cl.jml.myejemplo.ui.theme.MyEjemploTheme

class MainActivity : ComponentActivity() {
    private val viewModel = CounterViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyEjemploTheme {
                CounterScreen(viewModel)
            }
        }
    }

    private fun enableEdgeToEdge() {
        TODO("Not yet implemented")
    }
}