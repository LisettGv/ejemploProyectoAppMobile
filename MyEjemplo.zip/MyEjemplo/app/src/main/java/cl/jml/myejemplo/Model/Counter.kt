// model/Counter.kt
package cl.duoc.ntmp.model

//data class Counter(val value: Int = 0)


data class Counter(
    val value: Int = 0
)