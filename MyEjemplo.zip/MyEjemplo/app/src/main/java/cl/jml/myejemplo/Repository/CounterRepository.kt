// repository/CounterRepository.kt
package cl.duoc.ntmp.repository

import cl.duoc.ntmp.model.Counter

class CounterRepository {
    private var counter = Counter()

    fun getCounter(): Counter = counter

    fun increment(): Counter {
        counter = counter.copy(value = counter.value + 1)
        return counter
    }

    fun decrement(): Counter {
        counter = counter.copy(value = counter.value - 1)
        return counter
    }
}